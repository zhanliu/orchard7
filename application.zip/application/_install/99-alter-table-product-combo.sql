alter table `product`
Add column original_price double(10,2) AFTER `price`


alter table `combo`
Add column original_price double(10, 2) AFTER `price`
<?php
Class Item {
    public $item_id;
    public $item_type; // product or combo
    public $name;
    public $price;
    public $unit;
    public $quantity;
    public $description;
    public $img_url;
}
</div>

</div>
</div>
</div>
</div>




</div> <!-- container -->
</div> <!--wrap -->
</div> <!-- page-content -->

<footer role="contentinfo">
    <div class="clearfix">
        <ul class="list-unstyled list-inline pull-left">
            <li>AVANT © 2014</li>
        </ul>
        <button class="pull-right btn btn-inverse-alt btn-xs hidden-print" id="back-to-top"><i class="fa fa-arrow-up"></i></button>
    </div>
</footer>

</div> <!-- page-container -->

<!--
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

<script>!window.jQuery && document.write(unescape('%3Cscript src="assets/js/jquery-1.10.2.min.js"%3E%3C/script%3E'))</script>
<script type="text/javascript">!window.jQuery.ui && document.write(unescape('%3Cscript src="assets/js/jqueryui-1.10.3.min.js'))</script>
-->


<div id="ascrail2000" class="nicescroll-rails" style="width: 7px; z-index: 1029; cursor: default; position: absolute; top: 0px; left: -7px; height: 0px; display: none;"><div style="position: relative; top: 0px; float: right; width: 5px; height: 0px; border: 1px solid rgb(255, 255, 255); border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; background-color: rgb(66, 66, 66); background-clip: padding-box;"></div></div>
<div id="ascrail2001" class="nicescroll-rails" style="width: 7px; z-index: 1029; cursor: default; position: absolute; top: 0px; left: -7px; height: 0px; display: none;"><div style="position: relative; top: 0px; float: right; width: 5px; height: 0px; border: 1px solid rgb(255, 255, 255); border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; background-color: rgb(66, 66, 66); background-clip: padding-box;"></div></div>
<div id="ascrail2002" class="nicescroll-rails" style="width: 7px; z-index: 1300; cursor: default; position: absolute; top: 0px; left: -7px; height: 200px; display: none;"><div style="position: relative; top: 0px; float: right; width: 5px; height: 0px; border: 1px solid rgb(255, 255, 255); border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; background-color: rgb(66, 66, 66); background-clip: padding-box;"></div></div>
<div id="ascrail2003" class="nicescroll-rails" style="width: 7px; z-index: 1300; cursor: default; position: absolute; top: 0px; left: -7px; height: 200px; display: none;"><div style="position: relative; top: 0px; float: right; width: 5px; height: 0px; border: 1px solid rgb(255, 255, 255); border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; background-color: rgb(66, 66, 66); background-clip: padding-box;"></div></div>
</body></html>

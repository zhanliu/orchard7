<div id="page-content" style="min-height: 2911px;">
    <div id="wrap">
        <div id="page-heading">

            <ol class="breadcrumb">
                <li><a href="">控制面板</a></li>
                <li class="active">平台首页</li>
            </ol>

            <h1>欢迎使用果园七号管理系统</h1>

        </div>

        <div class="container">

            请从左侧菜单选择功能入口！<p>

            </p>
            <a href="#" onclick="getLocation()">Test</a>

        </div>
    </div>
</div>
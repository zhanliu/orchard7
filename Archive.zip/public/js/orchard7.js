function submit() {
    document.getElementById("myform").submit();
}